# Operator notes

## Commands

From the extracted folder. On Windows, use `py -3` in place of `python3`.

```sh
python3 market_lens.py enable                     # account service: install + start now
python3 market_lens.py status                     # heartbeat, successes/failures, next checks
python3 market_lens.py search --geo CA diesel
python3 market_lens.py search --geo ES --factor ACT-01
python3 market_lens.py lookup SC.1324952502        # latest diesel observation and receipt
python3 market_lens.py lookup SC.1324952502 --period 2026-09 --as-of 2026-11-18T23:59:59Z
python3 market_lens.py changes                    # latest 100 post-baseline cell events
python3 market_lens.py export latest-copy.csv      # refuses to overwrite an existing file
python3 market_lens.py backup safe-copy.sqlite3    # consistent online backup, includes committed WAL
python3 market_lens.py disable                    # unregister the account service; keep data
```

`lookup --as-of` fences receipts by local start/index and outcome time, not by reference period or a publisher's edition date. Before the first local acceptance, no value is returned. `--period 2026-09` alone is **not** a vintage query. For a period no longer in the publisher's rolling window, `record` can be an archived observation with its own `indexed` and `h`; `in_snapshot=false` and `current_value` is withheld. The enabled-feed policy applied at startup is also journaled: an explicit historical as-of lookup does not use a future enable/disable decision.

`python3 market_lens.py run` is a foreground alternative to installation. Closing that terminal stops the worker. `--no-dashboard` runs it headless. `run --port 8790` uses a different port in foreground. The default binds **only to loopback**; this app deliberately has no internet-facing authentication layer. Do not expose a public port on a personal computer. The same origin offers read-only `GET /api/status`, `/api/series?q=diesel&geo=CA`, `/api/series?geo=ES&factor=ACT-01`, `/api/detail?id=SC.1324952502`, `/api/changes` and `/latest.csv`. Viewing these never triggers a publisher request. `once [--feed ecb]` is optional maintenance for an otherwise stopped worker and checks only due feeds. Only one process may write a given data folder.

## Configure (optional)

Nothing needs configuring for the shipped schedule. For a different data path pass the global option *before* the command: `python3 market_lens.py --data /path/to/folder enable`. This is one service per user; enabling with another path changes what that service uses. Do not share one live SQLite folder between machines or use a network filesystem. Choose a local, writable directory. Run later commands with the same `--data` path.

To narrow the schedule, put `settings.json` inside the data directory, **not** beside this guide. Example:

```json
{"enabled":["ecb","ca-cpi","ca-prices"],"interval_minutes":{"ecb":60,"ca-prices":120}}
```

Run `enable` again to restart the service, or stop/restart your foreground process. Detected values remain in SQLite when you disable a feed. Remove the settings file and restart to restore defaults. `status` shows the effective schedule. The first pre-existing due time may still apply on restart. `feed_registry.csv` lists every key, default and minimum interval; the maximum is 1 day. There are at most three in-flight requests, at most one at a time per hostname, with host spacing. Failures back off exponentially (initially 5 minutes; BLS at least 6 hours); publisher `Retry-After` adds a shared host cooldown. There can be additional lag from publisher schedules, network, retries and validation. No scraping of arbitrary URLs or manual data entry.

## Uptime, recovery & uninstall

- **Windows:** Task Scheduler → Task Scheduler Library → `Market Lens Auto 3.5 - …`; runs under the signed-in account, no password, no three-day runtime limit. macOS: per-user LaunchAgent `org.marketlens.auto35`. Linux: systemd user service `market-lens-auto-35.service` (`systemctl --user status market-lens-auto-35.service`). An account policy may block these; confirm the heartbeat. If Python is moved or upgraded to a new path, re-run `enable` with the new interpreter.
- **Always-on Linux:** on a machine you administer, a systemd user service can also run before login/after logout if that account has **lingering** enabled. An administrator can approve `loginctl enable-linger USERNAME` for the collector account. This is optional and not done by this installer. Otherwise use a supervised foreground `run --no-dashboard` in your approved hosting environment, with persistent storage and outbound HTTPS. Closing the web monitor is never required for collection.
- **If it stops:** check your internet connection, system clock, disk space and `worker.log` (rotating, up to 3 backups). Closing Excel if it is holding `latest_live.csv` open can unblock atomic replacement on Windows; search and SQLite data collection are independent of a locked CSV. Restore the connection and leave the worker running; source errors retry automatically. After a process crash, restart the same service. Interrupted candidates are marked as such; existing successes and next-due times survive. A second writer is rejected. Local health reports `overdue` after the accepted receipt's next-due plus 5 minutes. Each series has a separate observation-age guard as well; these are tolerances, not release-calendar guarantees.
- **Backups:** `backup new-name.sqlite3` creates a consistent copy while running. To restore: stop the worker, keep the old folder as a backup, make a **new** data folder, put the backup inside named `macro-live.sqlite3`, restore any `settings.json`, then enable with the new `--data` path. Never mix a restored DB with old `-wal`/`-shm` files, or copy just an open DB file. Raw SHA-256 objects are deduplicated and compressed; SQLite append-only journal records are not automatically purged. Avoid synchronized cloud folders for the live WAL database.
- **Uninstall:** `disable` removes the service, not your evidence. Only delete `MarketLensLive` yourself if you no longer want the history; back it up first. The disabled service does not persist its own network activity. Your existing Market Lens workbooks, ZIPs and historical files are never modified.

## Collection semantics

1. Fetch **from the registered public API**, with rolling date windows (or the publisher's complete series/last-N endpoint). Commit the URL, request body when applicable, legal redirects within the same host, raw bytes, SHA-256, retrieval time and available HTTP metadata. A failed request is not a release.
2. Check publisher-specific series identities, frequencies, units where supplied, coordinates, dates, missing markers and overlap. Preserve publisher flags, including provisional/estimated values. New formats, unexplained deletions, backwards tails, date mismatches or broken contracts quarantine the feed, rather than silently substituting stale data. This conservative collector is not a press-wire; it does not promise to accept flash estimates before the end of their reference period.
3. Read back the stored object and check the normalized snapshot count before indexing a searchable receipt. `seen` is local body arrival; `indexed` is a local collector receipt. Neither is the publisher's exact announcement time nor proof an independent strategy saw the value. A publisher's release field is retained where available, not invented where absent. For derived YoY values, use only two available levels exactly 12 months apart; a missing baseline is not interpolated.
4. Track new numeric periods, revisions, values newly available, withdrawals, backfills, quality/edition changes and explicit missing notices. First snapshots (or parser baselines on contract upgrade) are not release events. A raw object may be fetched many times while unchanged. Alternative/sparse series keep their own dates. An empty, unflagged Eurostat grid coordinate is not a published observation; a new month on the common axis alone is not news.
5. `current_value` is withheld if the latest source poll is pending, failed, quarantined, overdue, or its series tail is too old/missing. A retained numeric value from the last accepted snapshot is labeled separately. `latest_live.csv` is refreshed during uptime (normally at least every minute), not a magic live file while the machine is off. The system sees editions available when it checks; revisions outside the requested window, first prints between polls and outages are not reconstructed. Review the source definitions before combining series or using a value in a model.
