"""Institutional 9-rule signal filter (Dalio macro logic + Simons statistical discipline)."""
import math, statistics
from decimal import Decimal
from reliability import read_export, FALLBACKS
from sources import M

def winsorize_zscore(values, cap=3.5):
    """Rule 5 & 6: Compute stationary Z-score of latest change and winsorize at +-cap."""
    clean = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    if len(clean) < 4:
        return None
    diffs = [b - a for a, b in zip(clean, clean[1:])]
    mu = statistics.mean(diffs[:-1]) if len(diffs) > 2 else statistics.mean(diffs)
    sd = statistics.stdev(diffs[:-1]) if len(diffs) > 2 else statistics.stdev(diffs)
    if sd <= 1e-12:
        return 0.0
    z = (diffs[-1] - mu) / sd
    return max(-cap, min(cap, z))

def pearson_corr(xs, ys):
    """Compute Pearson correlation on equal-length aligned lists."""
    n = min(len(xs), len(ys))
    if n < 4:
        return 0.0
    x, y = xs[-n:], ys[-n:]
    mx, my = statistics.mean(x), statistics.mean(y)
    num = sum((a - mx) * (b - my) for a, b in zip(x, y))
    den = math.sqrt(sum((a - mx) ** 2 for a in x) * sum((b - my) ** 2 for b in y))
    return num / den if den > 1e-12 else 0.0

def prune_correlated(series_histories, threshold=0.85):
    """Rule 7: Prune redundant series with |corr| > threshold, keeping the first representative."""
    kept = {}
    for sid, hist in series_histories.items():
        if any(abs(pearson_corr(hist, kh)) > threshold for kh in kept.values()):
            continue
        kept[sid] = hist
    return list(kept.keys())

def filter_signals(csv_path, freq=None, dedupe_groups=True, at=None):
    """Rules 1, 2, 4, 8: Fail-closed ingestion, frequency split, group deduplication, point-in-time order."""
    rows = read_export(csv_path, at=at)
    seen_groups = set()
    out = {}
    for r in rows:
        sid = r['series']
        meta = M.get(sid, {})
        if freq and meta.get('freq') != freq:
            continue
        grp = r.get('signal_group') or sid
        if dedupe_groups and grp in seen_groups:
            continue
        seen_groups.add(grp)
        out[sid] = {
            'value': Decimal(r['screened_value']),
            'freq': meta.get('freq', ''),
            'group': grp,
            'indexed_utc': r['snapshot_indexed_utc'],
            'usable_until_utc': r['usable_until_utc'],
        }
    for primary, backup in FALLBACKS.items():
        if primary not in out and backup in out:
            out[primary] = dict(out[backup], is_fallback=True, fallback_from=backup)
    return out

def classify_macro_quadrant(growth_z, inflation_z):
    """Rule 8 (Dalio): Map stationary growth & inflation Z-scores into 2x2 All-Weather quadrants."""
    if growth_z is None or inflation_z is None:
        return 'unknown'
    if growth_z >= 0 and inflation_z < 0:
        return 'rising_growth_falling_inflation'
    if growth_z >= 0 and inflation_z >= 0:
        return 'rising_growth_rising_inflation'
    if growth_z < 0 and inflation_z >= 0:
        return 'falling_growth_rising_inflation'
    return 'falling_growth_falling_inflation'

def revision_noise_ok(c, series_id, max_revisions=6):
    """Rule 9 (Simons): Reject series with excessive revision/withdrawal instability."""
    revs = c.execute("select count(*) from event where series=? and kind in ('revision','withdrawal')", (series_id,)).fetchone()[0]
    return revs <= max_revisions

def granger_causality_test(y_series, x_series, f_threshold=4.0):
    """Lag-1 Granger Causality F-test: tests if X_{t-1} predicts Y_t beyond Y_{t-1} alone."""
    n = min(len(y_series), len(x_series))
    if n < 10:
        return {'causal': False, 'f_stat': 0.0, 'reason': 'insufficient observations'}
    y = [float(v) for v in y_series[-n:]]
    x = [float(v) for v in x_series[-n:]]
    yt, yl, xl = y[1:], y[:-1], x[:-1]
    m = len(yt)
    my, ml = statistics.mean(yt), statistics.mean(yl)
    denom_r = sum((a - ml) ** 2 for a in yl)
    b1_r = sum((a - ml) * (b - my) for a, b in zip(yl, yt)) / denom_r if denom_r > 1e-12 else 0.0
    b0_r = my - b1_r * ml
    rss_r = sum((b - (b0_r + b1_r * a)) ** 2 for a, b in zip(yl, yt))

    # Unrestricted OLS: yt = c0 + c1*yl + c2*xl (3x3 normal equations)
    sx1, sx2 = sum(yl), sum(xl)
    sy = sum(yt)
    s11 = sum(a * a for a in yl)
    s22 = sum(a * a for a in xl)
    s12 = sum(a * b for a, b in zip(yl, xl))
    s1y = sum(a * b for a, b in zip(yl, yt))
    s2y = sum(a * b for a, b in zip(xl, yt))
    A = [[m, sx1, sx2, sy], [sx1, s11, s12, s1y], [sx2, s12, s22, s2y]]
    for i in range(3):
        piv = A[i][i]
        if abs(piv) < 1e-12:
            return {'causal': False, 'f_stat': 0.0, 'reason': 'collinear'}
        for j in range(i, 4):
            A[i][j] /= piv
        for k in range(3):
            if k != i:
                fac = A[k][i]
                for j in range(i, 4):
                    A[k][j] -= fac * A[i][j]
    c0, c1, c2 = A[0][3], A[1][3], A[2][3]
    rss_u = sum((b - (c0 + c1 * a1 + c2 * a2)) ** 2 for a1, a2, b in zip(yl, xl, yt))
    if rss_u <= 1e-12:
        return {'causal': rss_r > 1e-9, 'f_stat': 999.0 if rss_r > 1e-9 else 0.0}
    f_stat = ((rss_r - rss_u) / 1.0) / (rss_u / (m - 3))
    return {'causal': f_stat >= f_threshold, 'f_stat': round(f_stat, 4)}

def hurst_exponent(series):
    """Estimate Hurst Exponent (H) via Rescaled Range (R/S) on daily market series."""
    clean = [float(v) for v in series if v is not None and math.isfinite(float(v))]
    if len(clean) < 20:
        return {'hurst': None, 'regime': 'insufficient_data'}
    mean_x = statistics.mean(clean)
    dev = [x - mean_x for x in clean]
    cum = []
    s = 0.0
    for d in dev:
        s += d
        cum.append(s)
    r = max(cum) - min(cum)
    sd = statistics.stdev(clean)
    if sd <= 1e-12 or r <= 1e-12:
        return {'hurst': 0.5, 'regime': 'random_walk'}
    h = math.log(r / sd) / math.log(len(clean))
    regime = 'trending' if h > 0.55 else 'mean_reverting' if h < 0.45 else 'random_walk'
    return {'hurst': round(h, 4), 'regime': regime}
