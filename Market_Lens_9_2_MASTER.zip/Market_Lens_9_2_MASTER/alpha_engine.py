"""Alpha engine: regime detection, macro-surprise scoring, volatility-targeted sizing, and drift checks."""
import math
from decimal import Decimal
from strategy_adapter import load_screened_signals

def detect_regime(signals):
    """Classify macro/liquidity regime from fail-closed screened signals."""
    curve = signals.get('UST.DAILY.10Y2Y')
    sofr = signals.get('NYFED.SOFR')
    if curve is None:
        return {'regime': 'uncertain', 'risk_scale': 0.5, 'reason': 'missing UST.DAILY.10Y2Y'}
    if curve < Decimal('0'):
        return {'regime': 'defensive_inverted_curve', 'risk_scale': 0.5, 'reason': f'10Y-2Y={curve}'}
    if sofr is not None and sofr > Decimal('5.5'):
        return {'regime': 'tight_liquidity', 'risk_scale': 0.75, 'reason': f'SOFR={sofr}'}
    return {'regime': 'normal_expansion', 'risk_scale': 1.0, 'reason': f'10Y-2Y={curve}'}

def inverse_vol_weights(vols, target_vol=0.10, risk_scale=1.0, max_weight=0.40):
    """Volatility-targeted inverse-volatility portfolio weights with per-asset cap."""
    valid = {k: v for k, v in vols.items() if v and v > 0}
    if not valid:
        return {}
    inv = {k: 1.0 / v for k, v in valid.items()}
    total = sum(inv.values())
    raw = {k: min(max_weight, (inv[k] / total) * risk_scale) for k in valid}
    return raw

def drift_check(realized_turnover, max_turnover=0.50, missing_ratio=0.0, max_missing=0.20):
    """Fail-safe drift & data-completeness monitor."""
    issues = []
    if realized_turnover > max_turnover:
        issues.append(f'turnover {realized_turnover:.2%} > {max_turnover:.2%}')
    if missing_ratio > max_missing:
        issues.append(f'missing {missing_ratio:.2%} > {max_missing:.2%}')
    return {'ok': not issues, 'issues': issues}

def run_alpha_step(csv_path, asset_vols, realized_turnover=0.0, at=None):
    """End-to-end fail-closed alpha step from screened CSV to target weights."""
    signals = load_screened_signals(csv_path, at=at)
    reg = detect_regime(signals)
    weights = inverse_vol_weights(asset_vols, risk_scale=reg['risk_scale'])
    drift = drift_check(realized_turnover, missing_ratio=0.0 if signals else 1.0)
    if not drift['ok']:
        weights = {}
    return {'regime': reg, 'weights': weights, 'drift': drift, 'signal_count': len(signals)}

def kelly_fraction(expected_excess_return, variance, fraction=0.5, max_weight=0.40):
    """Fractional Kelly Criterion: f* = fraction * (mu / sigma^2), capped for safety."""
    if variance <= 1e-9 or expected_excess_return <= 0:
        return 0.0
    raw = fraction * (expected_excess_return / variance)
    return round(min(max_weight, max(0.0, raw)), 4)

def find_historical_analogs(current_vec, history, top_k=3):
    """Find top-k most similar historical macro states using Cosine Similarity & Euclidean Distance."""
    import math, statistics
    if not current_vec or not history:
        return {'analogs': [], 'expected_forward_return': None}
    norm_c = math.sqrt(sum(x * x for x in current_vec))
    scored = []
    for item in history:
        hv = item['vector']
        if len(hv) != len(current_vec):
            continue
        dist = math.sqrt(sum((a - b) ** 2 for a, b in zip(current_vec, hv)))
        norm_h = math.sqrt(sum(x * x for x in hv))
        cos = sum(a * b for a, b in zip(current_vec, hv)) / (norm_c * norm_h) if norm_c > 0 and norm_h > 0 else 0.0
        scored.append({'date': item.get('date', ''), 'distance': round(dist, 4), 'cosine_sim': round(cos, 4), 'forward_return': item['forward_return']})
    scored.sort(key=lambda x: (-x['cosine_sim'], x['distance']))
    top = scored[:top_k]
    rets = [x['forward_return'] for x in top]
    return {'analogs': top, 'expected_forward_return': round(statistics.mean(rets), 6) if rets else None}

def sentiment_guard(market_z):
    """Behavioral finance gate: dampen herding at extreme euphoria (> +2.0z) and prevent panic selling (< -2.0z)."""
    if market_z is None:
        return {'sentiment': 'neutral', 'risk_multiplier': 1.0}
    z = float(market_z)
    if z >= 2.0:
        return {'sentiment': 'extreme_euphoria', 'risk_multiplier': 0.75}
    if z <= -2.0:
        return {'sentiment': 'extreme_panic', 'risk_multiplier': 0.85}
    return {'sentiment': 'normal', 'risk_multiplier': 1.0}
