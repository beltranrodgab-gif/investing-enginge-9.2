"""Market Lens Auto 6.8 — scheduled official macro releases. No accounts, keys or manual observations."""
import argparse,contextlib,csv,datetime as dt,json,logging,logging.handlers,os,signal,sqlite3,sys,threading
from pathlib import Path
from sources import F,M,G,guard
from store import db,now,when,events,writer
from engine import status,catalogue,detail,run,export_rows
ROOT=Path(__file__).resolve().parent
def logs(home):
 home.mkdir(parents=True,exist_ok=True);lg=logging.getLogger('marketlens');lg.setLevel(logging.INFO);fmt=logging.Formatter('%(asctime)sZ %(levelname)s %(message)s');import time;fmt.converter=time.gmtime
 h=logging.handlers.RotatingFileHandler(home/'worker.log',maxBytes=1048576,backupCount=3,encoding='utf-8');h.setFormatter(fmt);lg.addHandler(h)
 if sys.stdout is not None and sys.stdout.isatty():lg.addHandler(logging.StreamHandler())
def main():
 a=argparse.ArgumentParser(description=__doc__);a.add_argument('--data',type=Path,default=Path.home()/'MarketLens62',help='state folder (default ~/MarketLens62)');s=a.add_subparsers(dest='cmd',required=True)
 p=s.add_parser('run',help='check immediately when due, then automatically thereafter');p.add_argument('--bind',default='127.0.0.1');p.add_argument('--port',default=8790,type=int);p.add_argument('--no-dashboard',action='store_true');p.add_argument('--checkpoint',type=Path,help='optional bounded .ml35.xz workspace checkpoint; local installations normally use the durable SQLite file directly');p=s.add_parser('once',help='check due feeds once, respecting retry limits');p.add_argument('--feed',choices=F);s.add_parser('enable',help='install and start a per-user background worker on this computer');s.add_parser('disable',help='remove per-user auto-start; keep collected data');s.add_parser('status');s.add_parser('audit',help='verify stored raw bytes, timestamps and every accepted normalized cell');p=s.add_parser('read-csv',help='only fresh screened rows; stale or offline exports yield no live values');p.add_argument('file',type=Path);s.add_parser('changes');s.add_parser('catalog');p=s.add_parser('search');p.add_argument('words',nargs='*');p.add_argument('--geo',choices=G);p.add_argument('--factor');p=s.add_parser('lookup');p.add_argument('series');p.add_argument('--period');p.add_argument('--as-of',help='UTC or other timezone-qualified decision time');p=s.add_parser('export');p.add_argument('new_csv',type=Path);p=s.add_parser('backup');p.add_argument('new_database',type=Path);g=a.parse_args();home=g.data.expanduser().resolve();j=lambda x:print(json.dumps(x,indent=2,ensure_ascii=False,default=str))
 if g.cmd in ('enable','disable'):
  import autostart;return autostart.main(g.cmd,home)
 if g.cmd=='read-csv':
  from reliability import read_export
  j(read_export(g.file));return 0
 if g.cmd=='catalog':j(list(M.values()));return 0
 if g.cmd in ('once','run'):
  logs(home);stop=threading.Event();signal.signal(signal.SIGINT,lambda *_:stop.set());signal.signal(signal.SIGTERM,lambda *_:stop.set());one=g.cmd=='once';r=run(home,one,getattr(g,'feed',None),getattr(g,'bind','127.0.0.1'),getattr(g,'port',8790),not getattr(g,'no_dashboard',False),stop,getattr(g,'checkpoint',None))
  if one:j(r);return int(any(e['state'] not in ('accepted','not due') for e in r))
  return 0
 with contextlib.closing(db(home)) as c:
  c.execute('pragma query_only=ON');c.execute('BEGIN')
  if g.cmd=='audit':
   from reliability import inspect_journal
   r=inspect_journal(c);j(r);return 0 if r['passed'] else 2
  if g.cmd=='status':j(status(c,home))
  elif g.cmd=='changes':j(events(c))
  elif g.cmd=='search':j([{k:r[k] for k in ('id','label','geos','factor','period','current_value','screened_value','quality','unit','state','usable_until_utc','snapshot_indexed_utc')} for r in catalogue(c,home,' '.join(g.words),g.geo or '',g.factor or '')])
  elif g.cmd=='lookup':j(detail(c,home,g.series,when(g.as_of) if g.as_of else None,g.period))
  elif g.cmd=='export':
   with g.new_csv.open('x',encoding='utf-8-sig',newline='') as f:csv.writer(f).writerows(export_rows(c,home))
   print(g.new_csv)
  elif g.cmd=='backup':
   # Reserve a new path exclusively; SQLite's backup API includes the committed WAL state.
   with g.new_database.open('xb'):pass
   with contextlib.closing(sqlite3.connect(g.new_database)) as new:c.backup(new);guard(new.execute('pragma integrity_check').fetchone()[0]=='ok','backup check failed')
   print(g.new_database)
 return 0
if __name__=='__main__':
 try:sys.exit(main())
 except (ValueError,OSError,RuntimeError,sqlite3.Error) as e:
  if sys.stderr:print('Market Lens:',str(e),file=sys.stderr)
  if logging.getLogger('marketlens').hasHandlers():logging.getLogger('marketlens').error('%s',e)
  sys.exit(1)
