"""End-to-end daily/monthly processor: Filter -> Regime/Quadrant -> Sizing -> Paper-Trade Log."""
import json
from pathlib import Path
from signal_filter import filter_signals, classify_macro_quadrant
from alpha_engine import detect_regime, inverse_vol_weights, drift_check
from macro_alerts import macro_diffusion


ALL_WEATHER_MAP = {
    'rising_growth_falling_inflation': {'EQUITY': 0.60, 'TREASURY': 0.25, 'GOLD': 0.10, 'TBILL': 0.05},
    'rising_growth_rising_inflation':  {'EQUITY': 0.35, 'GOLD': 0.30, 'COMMODITY': 0.25, 'TBILL': 0.10},
    'falling_growth_rising_inflation': {'GOLD': 0.35, 'COMMODITY': 0.25, 'TBILL': 0.30, 'TREASURY': 0.10},
    'falling_growth_falling_inflation':{'TREASURY': 0.50, 'GOLD': 0.25, 'TBILL': 0.25},
    'unknown':                         {'TBILL': 1.00},
}

def all_weather_allocation(quadrant, risk_scale=1.0):
    base = ALL_WEATHER_MAP.get(quadrant, ALL_WEATHER_MAP['unknown'])
    scaled = {k: round(v * risk_scale, 4) for k, v in base.items() if k != 'TBILL'}
    tbill = round(max(0.0, 1.0 - sum(scaled.values())), 4)
    if tbill > 0:
        scaled['TBILL'] = tbill
    return scaled

def run_processor(csv_path, asset_vols, prev_weights=None, growth_z=None, inflation_z=None, log_path=None, drift_threshold=0.05, at=None):
    """Run one complete fail-closed processor cycle and optionally log the decision."""
    prev_weights = prev_weights or {}
    filtered = filter_signals(csv_path, dedupe_groups=True, at=at)
    flat_signals = {k: v['value'] for k, v in filtered.items()}
    regime = detect_regime(flat_signals)
    quadrant = classify_macro_quadrant(growth_z, inflation_z)
    diffusion = macro_diffusion(flat_signals)
    target_w = inverse_vol_weights(asset_vols, risk_scale=regime['risk_scale'])
    max_drift = max((abs(target_w.get(a, 0.0) - prev_weights.get(a, 0.0)) for a in set(target_w) | set(prev_weights)), default=0.0)
    rebalance = max_drift >= drift_threshold
    final_w = target_w if rebalance else dict(prev_weights)
    turnover = sum(abs(final_w.get(a, 0.0) - prev_weights.get(a, 0.0)) for a in set(final_w) | set(prev_weights))
    drift = drift_check(turnover, missing_ratio=0.0 if filtered else 1.0)
    if not drift['ok']:
        final_w = {}
    record = {
        'regime': regime['regime'],
        'risk_scale': regime['risk_scale'],
        'quadrant': quadrant,
        'diffusion_pct': diffusion['diffusion_pct'],
        'rebalance_triggered': rebalance,
        'max_drift': round(max_drift, 6),
        'weights': final_w,
        'all_weather_weights': all_weather_allocation(quadrant, regime['risk_scale']) if drift['ok'] else {},
        'drift_ok': drift['ok'],
        'filtered_count': len(filtered),
    }
    if log_path is not None:
        Path(log_path).parent.mkdir(parents=True, exist_ok=True)
        with Path(log_path).open('a', encoding='utf-8') as f:
            f.write(json.dumps(record) + '\n')
    return record

def confirm_regime(recent_regimes, confirm_days=2):
    """Hysteresis gate: require confirm_days consecutive identical regimes before switching."""
    if not recent_regimes:
        return 'uncertain'
    if len(recent_regimes) >= confirm_days and len(set(recent_regimes[-confirm_days:])) == 1:
        return recent_regimes[-1]
    return recent_regimes[0]

def drawdown_guard(weights, current_nav, peak_nav, max_dd=0.10):
    """Circuit breaker: halve risky weights into TBILL if drawdown exceeds max_dd."""
    if peak_nav <= 0 or (current_nav / peak_nav - 1.0) > -max_dd:
        return weights
    scaled = {k: round(v * 0.5, 4) for k, v in weights.items() if k != 'TBILL'}
    scaled['TBILL'] = round(max(0.0, 1.0 - sum(scaled.values())), 4)
    return scaled

def bayesian_regime_update(prior_probs, likelihoods, floor=0.05):
    """Bayesian posterior regime probabilities: P(R|x) proportional to P(x|R) * P_prior(R)."""
    unnorm = {r: max(floor, prior_probs.get(r, 0.25)) * max(1e-6, likelihoods.get(r, 0.25)) for r in set(prior_probs) | set(likelihoods)}
    total = sum(unnorm.values())
    return {r: round(v / total, 6) for r, v in unnorm.items()}
