"""Macroeconomic change digest, diffusion index, and regime-shift alerts."""
import json
from pathlib import Path
from alpha_engine import detect_regime
from strategy_adapter import load_screened_signals

def macro_diffusion(signals):
    """Share of positive vs negative macro/curve signals across tracked series."""
    curve = signals.get('UST.DAILY.10Y2Y')
    pos = sum(1 for k, v in signals.items() if k.startswith('FIN.') and k.endswith('.curve') and v > 0)
    neg = sum(1 for k, v in signals.items() if k.startswith('FIN.') and k.endswith('.curve') and v <= 0)
    if curve is not None:
        pos += int(curve > 0)
        neg += int(curve <= 0)
    total = pos + neg
    return {'positive': pos, 'negative': neg, 'diffusion_pct': round(100.0 * pos / total, 2) if total else None}

def check_macro_alerts(c, csv_path, alert_log=None, at=None):
    """Evaluate recent macro revisions/withdrawals and regime shifts; optionally append to JSONL."""
    signals = load_screened_signals(csv_path, at=at)
    regime = detect_regime(signals)
    diffusion = macro_diffusion(signals)
    revs = c.execute("select count(*) from event where kind in ('revision','withdrawal')").fetchone()[0]
    alert = {
        'regime': regime['regime'],
        'risk_scale': regime['risk_scale'],
        'diffusion_pct': diffusion['diffusion_pct'],
        'revision_or_withdrawal_events': revs,
        'signals_active': len(signals),
    }
    if alert_log is not None:
        Path(alert_log).parent.mkdir(parents=True, exist_ok=True)
        with Path(alert_log).open('a', encoding='utf-8') as f:
            f.write(json.dumps(alert) + '\n')
    return alert

def detect_macro_chains(signals, inflation_z=None, yield_change=None):
    """Identify economic cause-and-effect chains from screened macro signals."""
    chains = []
    curve = signals.get('UST.DAILY.10Y2Y')
    sofr = signals.get('NYFED.SOFR')
    diff = macro_diffusion(signals).get('diffusion_pct')
    if curve is not None and curve < 0 and sofr is not None and float(sofr) > 4.5:
        chains.append({'chain': 'tightening_to_slowdown', 'signal': f'10Y-2Y={curve}, SOFR={sofr}', 'implication': 'credit tightening -> growth slowdown -> favor TREASURY/TBILL'})
    if curve is not None and float(curve) > 0.25 and diff is not None and diff >= 60.0:
        chains.append({'chain': 'reflation_expansion', 'signal': f'10Y-2Y={curve}, diffusion={diff}%', 'implication': 'broadening expansion -> favor EQUITY/COMMODITY'})
    if inflation_z is not None and inflation_z < -0.5 and yield_change is not None and yield_change < 0:
        chains.append({'chain': 'disinflationary_pivot', 'signal': f'inf_z={inflation_z}, dY={yield_change}', 'implication': 'easing cycle -> favor TREASURY/EQUITY'})
    return chains

def relative_macro_divergence(z_a, z_b, threshold=1.0):
    """Cross-country relative value: spot when one economy's macro Z-score diverges from another's."""
    if z_a is None or z_b is None:
        return {'divergent': False, 'spread_z': None}
    spread = round(float(z_a) - float(z_b), 4)
    return {'divergent': abs(spread) >= threshold, 'spread_z': spread, 'leader': 'A' if spread > 0 else 'B'}

def inflation_yield_divergence(inflation_z, yield_change):
    """Flag when inflation is hot (> +0.5z) but long yields are falling (< 0), signaling bond-market slowdown fears."""
    if inflation_z is None or yield_change is None:
        return False
    return float(inflation_z) > 0.5 and float(yield_change) < 0.0
