"""J.A.R.V.I.S. Supervisor: monitors system health, investing operations, and forward macro outlook."""
from macro_alerts import detect_macro_chains
from strategy_adapter import load_screened_signals

def jarvis_briefing(status_dict, current_proc, csv_path=None):
    """Return a structured supervisor briefing covering health, operations, and future outlook."""
    online = bool(status_dict.get('worker_online'))
    ok_feeds = status_dict.get('accepted_feeds', 0)
    tot_feeds = status_dict.get('enabled_feeds', 0)
    warnings = []
    if not online:
        warnings.append('Worker offline: fail-closed gate active (no trades executed).')
    if tot_feeds and ok_feeds < tot_feeds:
        warnings.append(f'{tot_feeds - ok_feeds} feed(s) pending or retrying.')
    regime = current_proc.get('regime', 'uncertain')
    outlook = 'Normal expansion: favor equities/growth while monitoring yield curve.'
    if regime == 'defensive_inverted_curve':
        outlook = 'Inverted yield curve: elevated recession risk over next 6-12 months; favor Treasuries, Gold, and T-Bills.'
    elif regime == 'tight_liquidity':
        outlook = 'Tight liquidity: elevated funding rates may slow growth; risk scaled to 75%.'
    chains = []
    if csv_path:
        try:
            sigs = load_screened_signals(csv_path)
            chains = detect_macro_chains(sigs)
        except Exception:
            pass
    return {
        'status': 'NOMINAL' if online and not warnings else 'ATTENTION',
        'feeds': f'{ok_feeds}/{tot_feeds} passing',
        'warnings': warnings,
        'outlook': outlook,
        'chains': chains,
    }

def generate_report(period, history, briefing):
    """Generate a daily, weekly, monthly, or yearly Obsidian Economics executive report."""
    window = {'daily': 1, 'weekly': 7, 'monthly': 30, 'yearly': 365}.get(period, 1)
    slice_h = history[-window:] if history else []
    avg_risk = round(sum(h.get('risk_scale', 0.0) for h in slice_h) / len(slice_h), 4) if slice_h else None
    regimes = [h.get('regime') for h in slice_h if h.get('regime')]
    top_regime = max(set(regimes), key=regimes.count) if regimes else 'n/a'
    return {
        'company': 'Obsidian Economics',
        'period': period,
        'decisions_count': len(slice_h),
        'dominant_regime': top_regime,
        'avg_risk_scale': avg_risk,
        'status': briefing.get('status', 'UNKNOWN'),
        'outlook': briefing.get('outlook', ''),
    }
