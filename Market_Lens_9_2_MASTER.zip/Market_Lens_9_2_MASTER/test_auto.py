"""Offline replay & fault tests. Fixtures are never read by the live worker. No login services are installed by tests."""
import collections,contextlib,csv,datetime as dt,io,json,os,plistlib,sqlite3,tempfile,time,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
import xml.etree.ElementTree as ET
import sources as s,store as h,engine as e,materialize as mat,autostart as au
from net import FetchFailure,delay
ROOT=Path(__file__).resolve().parent
with zipfile.ZipFile(ROOT/'qa/offline-fixtures.zip') as f:
 META=json.loads(f.read('test_manifest.json'));FIX={k:f.read(k) for k in s.F}
BASE=h.when(META['clock']);JT=lambda b:json.loads(b);B=lambda j:json.dumps(j,ensure_ascii=False).encode()
class Ledger(unittest.TestCase):
 def setUp(self):self.dir=tempfile.TemporaryDirectory();self.p=Path(self.dir.name);self.c=h.db(self.p,True)
 def tearDown(self):self.c.close();self.dir.cleanup()
 def put(self,k='uk-cpi',sec=0,b=None,fail=None,force=False):
  t=BASE+dt.timedelta(seconds=sec);tick=iter(range(60));f=lambda:t+dt.timedelta(milliseconds=next(tick));
  def get(url,post):
   if fail is not None:raise fail
   return FIX[k] if b is None else b,url,'',''
  return h.capture(self.c,k,s.F[k]['minutes'],f,get,force)
 def lens(self,k,i,sec):return h.lens(self.c,k,i,BASE+dt.timedelta(seconds=sec))
 def test_all_26_live_formats(self):
  for k in s.F:
   result=self.put(k);self.assertEqual(result['state'],'accepted',(k,result));self.assertEqual(result['observations'],META['counts'][k])
  self.assertEqual(self.c.execute('select count(*) from ready').fetchone()[0],26);self.assertEqual(len(s.M),154);self.assertEqual(len(h.events(self.c)),0);self.assertEqual(len(e.catalogue(self.c,self.p,geo='CA',fac='INF-01',d=BASE+dt.timedelta(seconds=2))),2)
 def test_schedule_persists_on_reopen(self):
  r=self.put();self.assertEqual(r['state'],'accepted');self.c.close();self.c=h.db(self.p);self.assertEqual(self.put(sec=300)['state'],'not due');self.assertEqual(self.put(sec=3601)['kind'],'unchanged');self.assertEqual(self.c.execute('select count(*) from object').fetchone()[0],1)
 def test_release_revision_baseline_and_no_time_travel(self):
  r=self.put();self.assertEqual(r['kind'],'baseline');self.assertIsNone(self.lens('uk-cpi','ONS.D7G7',-1)['record']);old=JT(FIX['uk-cpi']);rv=old['months'][-1];old_value=rv['value'];rv['value']=old['description']['number']='4.2';rr=self.put(sec=3700,b=B(old));self.assertEqual((rr['new_periods'],rr['revisions']),(0,1));self.assertEqual(self.lens('uk-cpi','ONS.D7G7',10)['current_value'],old_value);self.assertEqual(self.lens('uk-cpi','ONS.D7G7',3710)['current_value'],'4.2');
  old['months'].append(dict(rv,date='2026 NOV',year='2026',month='November',value='4.5'));old['description'].update(date='2026 NOV',number='4.5',releaseDate='2026-12-15T00:00:00Z');r=self.put(sec=32*86400,b=B(old));self.assertEqual(r['new_periods'],1);self.assertEqual({z['kind'] for z in h.events(self.c)},{'revision','new period'});self.assertEqual(h.events(self.c)[0]['t'],'2026-11')
 def test_asof_uses_policy_at_decision_time(self):
  self.put();e.record_policy(self.c,h.iso(BASE),{'uk-cpi':60});e.record_policy(self.c,h.iso(BASE+dt.timedelta(seconds=10)),{'ecb':30});
  self.assertEqual(e.detail(self.c,self.p,'ONS.D7G7',BASE+dt.timedelta(seconds=3))['state'],'accepted');self.assertEqual(e.detail(self.c,self.p,'ONS.D7G7',BASE+dt.timedelta(seconds=12))['state'],'disabled')
 def test_failed_poll_preserves_but_blocks(self):
  self.put();r=self.put(sec=3602,fail=OSError('fixture network failure'));self.assertEqual(r['state'],'failed');z=self.lens('uk-cpi','ONS.D7G7',3604);self.assertIsNone(z['current_value']);self.assertIsNotNone(z['last_numeric']);self.assertEqual(self.put(sec=3610)['state'],'not due');self.assertEqual(self.put(sec=3910)['kind'],'unchanged')
 def test_host_retry_after_is_shared_and_survives_restart(self):
  self.put(fail=FetchFailure('HTTP 429',900));self.assertEqual(self.put('uk-wood',sec=120)['state'],'not due');self.c.close();self.c=h.db(self.p);self.assertEqual(self.put('uk-wood',sec=300)['state'],'not due');self.assertEqual(self.put('uk-wood',sec=902)['state'],'accepted');self.assertEqual(delay('600'),600)
 def test_bls_quota_floor_on_failure(self):
  r=self.put('us-bls',fail=FetchFailure('HTTP 503'));self.assertGreaterEqual((h.when(r['next_check'])-BASE).total_seconds(),21600);self.assertEqual(self.put('us-bls',sec=2000)['state'],'not due')
 def test_embedded_missing_vs_zero(self):
  self.put('eu-jobs');x=self.lens('eu-jobs','une_rt_m.ES',1);self.assertEqual(x['period'],'2026-09');self.assertIsNotNone(x['current_value']);self.put('us-bls');y=self.lens('us-bls','BLS.CPI.YOY',1);self.assertEqual(y['state'],'latest value missing');self.assertIsNone(y['current_value']);self.assertIsNotNone(y['last_numeric']['value'])
 def test_no_zero_for_withdrawn_price(self):
  self.put('ca-prices');j=JT(FIX['ca-prices']);v=next(x['object'] for x in j if x['object']['vectorId']==1230995983)['vectorDataPoint'][-1];v.update(value=None,statusCode=1);res=self.put('ca-prices',sec=3605,b=B(j));self.assertEqual(res['revisions'],1);event=h.events(self.c)[0];self.assertEqual((event['kind'],event['new_x']),('withdrawn',None));self.assertIsNone(self.lens('ca-prices','SC.1230995983',3610)['current_value'])
 def test_gap_fails_closed_on_first_ons_body(self):
  j=JT(FIX['uk-cpi']);j['months'].pop(12);r=self.put(b=B(j));self.assertEqual(r['state'],'quarantined');self.assertIsNone(self.lens('uk-cpi','ONS.D7G7',5)['last_numeric'])
 def test_unexplained_missing_overlap_quarantined(self):
  self.put('ny-sofr');j=JT(FIX['ny-sofr']);j['refRates'].pop(10);r=self.put('ny-sofr',sec=1850,b=B(j));self.assertEqual(r['state'],'quarantined');self.assertIn('silently removed',r['reason'])
 def test_overdue_then_old_reference(self):
  self.put();self.assertEqual(self.lens('uk-cpi','ONS.D7G7',4000)['state'],'overdue');r=self.put(sec=120*86400);self.assertEqual(r['state'],'accepted');self.assertEqual(self.lens('uk-cpi','ONS.D7G7',120*86400+1)['state'],'reference old')
 def test_pending_then_interrupted(self):
  self.put();d=BASE+dt.timedelta(seconds=3605)
  with self.c:self.c.execute('insert into poll(feed,started,request_url,request_body) values(?,?,?,?)',('uk-cpi',h.iso(d),'https://www.ons.gov.uk/',''))
  self.assertEqual(self.lens('uk-cpi','ONS.D7G7',3606)['state'],'checking');self.assertEqual(h.recover(self.c,s.F,lambda:d+dt.timedelta(seconds=5)),1);self.assertEqual(self.lens('uk-cpi','ONS.D7G7',3615)['state'],'interrupted');self.assertEqual(self.put(sec=3616)['state'],'accepted')
 def test_checkpoint_and_csv(self):
  self.put();mat.latest(self.c,self.p);self.assertTrue((self.p/'latest_live.csv').is_file());path=self.p/'copy.ml35.xz';mat.checkpoint(self.p,path);other=self.p/'another';self.assertTrue(mat.restore_if_absent(other,path));self.assertFalse(mat.restore_if_absent(other,path));
  with contextlib.closing(h.db(other)) as c:self.assertEqual(c.execute('select count(*) from ready').fetchone()[0],1)
 def test_install_confirms_real_new_heartbeat(self):
  start=h.now();e.pulse(self.c,h.iso(start),'running');self.assertTrue(au.confirm_start(self.p,start,.01));e.pulse(self.c,h.iso(start),'stopped')
  with self.assertRaises(RuntimeError):au.confirm_start(self.p,start,0)
 def test_singleton_and_readonly_ledger(self):
  with h.writer(self.p):
   with self.assertRaises(RuntimeError):
    with h.writer(self.p):pass
  self.put()
  with self.assertRaises(sqlite3.IntegrityError):self.c.execute('delete from ready')
 def test_plan_range_and_host_pacing(self):
  jobs=e.select_due(self.c,s.F,{}, {},BASE,500);self.assertLessEqual(len(jobs),3);self.assertEqual(len(set(hh for _,hh in jobs)),len(jobs));(self.p/'settings.json').write_text(json.dumps({'interval_minutes':{'us-bls':1}}))
  with self.assertRaises(ValueError):e.settings(self.p)
 def test_automatic_loop_rechecks_without_another_command(self):
  # Real run loop, WAL, parsing, change journal and persistent plan. Only time and publisher I/O are simulated.
  (self.p/'settings.json').write_text('{"enabled":["uk-cpi"]}');counter=[0];clock=[BASE];orig=h.capture;j=JT(FIX['uk-cpi']);j['months'][-1]['value']=j['description']['number']='4.3';revised=B(j);j['months'].append(dict(j['months'][-1],date='2026 NOV',year='2026',month='November',value='4.5'));j['description'].update(date='2026 NOV',number='4.5',releaseDate='2026-12-15T00:00:00Z');new_period=B(j)
  class Stop:
   steps=0
   def is_set(self):return counter[0]>=3 or self.steps>300
   def wait(self,t):self.steps+=1;clock[0]+=dt.timedelta(days=32) if counter[0]==2 and clock[0]<BASE+dt.timedelta(days=30) else dt.timedelta(seconds=75);time.sleep(.003)
  def mockcap(c,k,mins):
   snap_time=clock[0];it=iter(range(25));r=orig(c,k,mins,lambda:snap_time+dt.timedelta(milliseconds=next(it)),lambda url,post:((FIX[k],revised,new_period)[min(counter[0],2)],url,'',''));counter[0]+=int(r['state']=='accepted');return r
  # Host spacing uses a monotonic clock (2s), advance it along with the fictitious wall clock.
  with patch.object(e,'now',lambda:clock[0]),patch.object(e,'capture',mockcap),patch.object(e.time,'monotonic',lambda:100+(clock[0]-BASE).total_seconds()):e.run(self.p,web=False,stop=Stop())
  self.assertEqual(counter[0],3);self.assertEqual(self.c.execute('select count(*) from ready').fetchone()[0],3);self.assertEqual([x['kind'] for x in h.events(self.c)],['new period','revision'])
class Parsers(unittest.TestCase):
 def test_dimension_guards(self):
  j=JT(FIX['ca-cpi']);j[0]['object']['coordinate']='3.3'
  with self.assertRaises(ValueError):s.parse('ca-cpi',B(j),BASE)
  j=JT(FIX['eu-hicp']);j['dimension']['unit']['category']['index']={'INDEX':0}
  with self.assertRaises(ValueError):s.parse('eu-hicp',B(j),BASE)
 def test_frequency_and_future(self):
  j=JT(FIX['ca-jobs']);j[0]['object']['vectorDataPoint'][1]['frequencyCode']=6
  with self.assertRaises(ValueError):s.parse('ca-jobs',B(j),BASE)
  j=JT(FIX['ca-cpi']);j[0]['object']['vectorDataPoint'][-1]['releaseTime']='2099-01-01T08:30'
  with self.assertRaises(ValueError):s.parse('ca-cpi',B(j),BASE)
 def test_ecb_hole_and_future_ons(self):
  tree=ET.fromstring(FIX['ecb']);p=next(x for x in tree.iter() if any('time' in r.attrib for r in x));p.remove(list(p)[15]);
  with self.assertRaises(ValueError):s.parse('ecb',ET.tostring(tree),BASE)
  j=JT(FIX['uk-ppi']);j['description']['releaseDate']='2099-01-01T00:00:00Z'
  with self.assertRaises(ValueError):s.parse('uk-ppi',B(j),BASE)
 def test_geo_and_no_lookahead_derivations(self):
  o=s.parse('ca-jobs',FIX['ca-jobs'],BASE);self.assertTrue(all('-Q' in t for i,t in o.cells));o=s.parse('ca-cpi',FIX['ca-cpi'],BASE);i='SC.CPI.YOY';period='2026-10';a,b=[s.D(o.cells['SC.41690973',t][0]) for t in ('2025-10',period)];self.assertAlmostEqual(float(o.cells[i,period][0]),float(100*(b/a-1)),6)
 def test_new_year_requests_roll_forward(self):
  a=s.request('oecd-gdp',dt.date(2026,11,18))[0];b=s.request('oecd-gdp',dt.date(2027,1,8))[0];self.assertIn('2023-Q1',a);self.assertIn('2024-Q1',b);self.assertEqual(s.quarter_floor_start('2025-12'),'2026-Q1');self.assertIn('2027-01-08',s.request('ca-cpi',dt.date(2027,1,8))[0])
 def test_login_manifests_no_admin_and_no_password(self):
  args=['/some path/python','/app/market_lens.py','--data','/data folder','run'];mac=plistlib.loads(au.mac_agent(args));self.assertEqual(mac['ProgramArguments'],args);self.assertTrue(mac['RunAtLoad']);linux=au.linux_unit(args).decode();self.assertIn('Restart=on-failure',linux);self.assertIn('"/some path/python"',linux);x=ET.fromstring(au.win_task(args,'COMPUTER\\Example'));tags={p.tag.split('}')[-1]:p.text for p in x.iter()};self.assertEqual(tags['LogonType'],'InteractiveToken');self.assertEqual(tags['ExecutionTimeLimit'],'PT0S');self.assertEqual(tags['RunLevel'],'LeastPrivilege');self.assertNotIn('Password',tags)

 def test_alpha_engine_regime_and_sizing(self):
  import alpha_engine as ae
  from decimal import Decimal
  r = ae.detect_regime({'UST.DAILY.10Y2Y': Decimal('-0.25'), 'NYFED.SOFR': Decimal('4.5')})
  self.assertEqual(r['regime'], 'defensive_inverted_curve')
  self.assertEqual(r['risk_scale'], 0.5)
  w = ae.inverse_vol_weights({'SPY': 0.15, 'TLT': 0.12, 'GLD': 0.14}, risk_scale=0.5)
  self.assertTrue(abs(sum(w.values()) - 0.5) < 1e-6)


 def test_macro_diffusion_and_alerts(self):
  import macro_alerts as ma
  from decimal import Decimal
  d = ma.macro_diffusion({'UST.DAILY.10Y2Y': Decimal('0.35'), 'FIN.USA.curve': Decimal('0.20'), 'FIN.DEU.curve': Decimal('-0.10')})
  self.assertEqual(d['positive'], 2)
  self.assertEqual(d['negative'], 1)
  self.assertAlmostEqual(d['diffusion_pct'], 66.67, places=2)


 def test_paper_trader_vol_and_costs(self):
  import paper_trader as pt
  vols = pt.realized_vols({'SPY': [100, 101, 100.5, 102, 101.5], 'TLT': [90, 90.2, 90.1, 90.4, 90.3]})
  self.assertTrue('SPY' in vols and 'TLT' in vols and vols['SPY'] > 0)


 def test_search_synonyms_and_ranking(self):
  import tempfile
  with tempfile.TemporaryDirectory() as td:
   p = Path(td); c = h.db(p, True)
   res = e.catalogue(c, p, q='rates')
   self.assertTrue(any('SOFR' in r['id'] or 'IRLT' in r['id'] for r in res))


 def test_signal_filter_rules(self):
  import signal_filter as sf
  z = sf.winsorize_zscore([1.0, 1.1, 1.25, 1.35, 10.0], cap=3.5)
  self.assertEqual(z, 3.5)
  kept = sf.prune_correlated({'A': [1, 2, 3, 4, 5], 'B': [2, 4, 6, 8, 10], 'C': [5, 3, 4, 1, 2]}, threshold=0.85)
  self.assertEqual(kept, ['A', 'C'])


 def test_macro_quadrant_and_revision_gate(self):
  import signal_filter as sf
  self.assertEqual(sf.classify_macro_quadrant(1.2, -0.5), 'rising_growth_falling_inflation')
  self.assertEqual(sf.classify_macro_quadrant(-0.8, 1.5), 'falling_growth_rising_inflation')


 def test_daily_processor_cycle(self):
  import daily_processor as dp, tempfile
  with tempfile.TemporaryDirectory() as td:
   p = Path(td); c = h.db(p, True); csv_p = p / 'latest.csv'
   mat.latest(c, p); c.close()
   rec = dp.run_processor(p / 'latest_live.csv', {'SPY': 0.15, 'TLT': 0.12}, prev_weights={'SPY': 0.4, 'TLT': 0.6}, growth_z=0.8, inflation_z=-0.3)
   self.assertFalse(rec['drift_ok'])
   self.assertEqual(rec['quadrant'], 'rising_growth_falling_inflation')


 def test_all_weather_allocation(self):
  import daily_processor as dp
  w = dp.all_weather_allocation('falling_growth_falling_inflation', risk_scale=0.5)
  self.assertEqual(w['TREASURY'], 0.25)
  self.assertEqual(w['GOLD'], 0.125)
  self.assertEqual(w['TBILL'], 0.625)


 def test_monte_carlo_confidence(self):
  import paper_trader as pt
  res = pt.monte_carlo_confidence([0.01, 0.02, 0.015, 0.005, 0.012, 0.018, 0.011], trials=200)
  self.assertTrue(res['ok'])
  self.assertTrue(res['ci_95'][0] > 0)
  self.assertEqual(res['prob_beat_benchmark'], 1.0)


 def test_hysteresis_and_drawdown_guard(self):
  import daily_processor as dp
  self.assertEqual(dp.confirm_regime(['normal_expansion', 'defensive_inverted_curve'], confirm_days=2), 'normal_expansion')
  self.assertEqual(dp.confirm_regime(['normal_expansion', 'defensive_inverted_curve', 'defensive_inverted_curve'], confirm_days=2), 'defensive_inverted_curve')
  w = dp.drawdown_guard({'EQUITY': 0.60, 'TREASURY': 0.30, 'TBILL': 0.10}, current_nav=88.0, peak_nav=100.0, max_dd=0.10)
  self.assertEqual(w['EQUITY'], 0.30)
  self.assertEqual(w['TBILL'], 0.55)


 def test_bayesian_regime_update(self):
  import daily_processor as dp
  post = dp.bayesian_regime_update({'expansion': 0.7, 'recession': 0.3}, {'expansion': 0.2, 'recession': 0.8})
  self.assertAlmostEqual(sum(post.values()), 1.0, places=5)
  self.assertTrue(post['recession'] > 0.3)


 def test_generate_orders(self):
  import trade_signals as ts
  orders = ts.generate_orders({'EQUITY': 0.40, 'GOLD': 0.20, 'TBILL': 0.40}, {'EQUITY': 0.60, 'GOLD': 0.20, 'TBILL': 0.20}, portfolio_value=5000.0)
  by_a = {o['asset']: o for o in orders}
  self.assertEqual(by_a['EQUITY']['action'], 'BUY')
  self.assertEqual(by_a['EQUITY']['amount_usd'], 1000.0)
  self.assertEqual(by_a['GOLD']['action'], 'HOLD')
  self.assertEqual(by_a['TBILL']['action'], 'SELL')


 def test_kelly_fraction(self):
  import alpha_engine as ae
  self.assertEqual(ae.kelly_fraction(-0.02, 0.04), 0.0)
  self.assertEqual(ae.kelly_fraction(0.08, 0.04, fraction=0.5, max_weight=0.40), 0.40)
  self.assertEqual(ae.kelly_fraction(0.02, 0.04, fraction=0.5, max_weight=0.40), 0.25)


 def test_historical_analogs(self):
  import alpha_engine as ae
  hist = [
   {'date': '2020-03', 'vector': [-2.0, -0.5, 0.2], 'forward_return': 0.18},
   {'date': '2022-06', 'vector': [-0.5, 2.5, -0.4], 'forward_return': -0.10},
   {'date': '2023-10', 'vector': [-0.4, 2.2, -0.3], 'forward_return': -0.06},
  ]
  res = ae.find_historical_analogs([-0.45, 2.3, -0.35], hist, top_k=2)
  self.assertEqual(len(res['analogs']), 2)
  self.assertAlmostEqual(res['expected_forward_return'], -0.08, places=4)


 def test_detect_macro_chains(self):
  import macro_alerts as ma
  from decimal import Decimal
  chains = ma.detect_macro_chains({'UST.DAILY.10Y2Y': Decimal('-0.30'), 'NYFED.SOFR': Decimal('5.2')}, inflation_z=-0.8, yield_change=-0.2)
  names = [c['chain'] for c in chains]
  self.assertIn('tightening_to_slowdown', names)
  self.assertIn('disinflationary_pivot', names)


 def test_granger_causality_filter(self):
  import signal_filter as sf
  x = [1, 3, 2, 5, 4, 7, 6, 9, 8, 11, 10, 13]
  y = [0] + [2.0 * v + 0.1 for v in x[:-1]]
  res = sf.granger_causality_test(y, x)
  self.assertTrue(res['causal'])
  self.assertTrue(res['f_stat'] > 4.0)


 def test_hurst_exponent(self):
  import signal_filter as sf
  trend = [100 + i * 1.5 for i in range(30)]
  res = sf.hurst_exponent(trend)
  self.assertEqual(res['regime'], 'trending')
  self.assertTrue(res['hurst'] > 0.55)


 def test_macro_divergences(self):
  import macro_alerts as ma
  d = ma.relative_macro_divergence(1.4, -0.2, threshold=1.0)
  self.assertTrue(d['divergent'])
  self.assertEqual(d['leader'], 'A')
  self.assertTrue(ma.inflation_yield_divergence(0.9, -0.15))


 def test_event_engine_prediction(self):
  import event_engine as ee
  evs = [
   {'title': 'Rate hike cycle pause', 'category': 'monetary', 'tags': ['fed', 'pause'], 'outcome': 'equities rally', 'forward_return': 0.12},
   {'title': 'Rate pause 2019', 'category': 'monetary', 'tags': ['fed', 'pause'], 'outcome': 'equities rally', 'forward_return': 0.15},
   {'title': 'Election uncertainty', 'category': 'political', 'tags': ['election'], 'outcome': 'volatility', 'forward_return': -0.04},
  ]
  res = ee.predict_event_outcome(evs, query='fed pause')
  self.assertEqual(res['matched_count'], 2)
  self.assertTrue(res['mean_return'] > 0.10)
  self.assertTrue(res['kelly_size'] > 0.0)


 def test_sentiment_guard(self):
  import alpha_engine as ae
  self.assertEqual(ae.sentiment_guard(2.5)['sentiment'], 'extreme_euphoria')
  self.assertEqual(ae.sentiment_guard(-2.5)['sentiment'], 'extreme_panic')
  self.assertEqual(ae.sentiment_guard(0.5)['risk_multiplier'], 1.0)


 def test_adapt_risk_from_paper(self):
  import paper_trader as pt
  self.assertEqual(pt.adapt_risk_from_paper([-0.01, -0.02, -0.005, 0.001, -0.01]), 0.5)
  self.assertEqual(pt.adapt_risk_from_paper([0.01, 0.02, 0.015, 0.005, 0.012]), 1.0)


 def test_stock_selector(self):
  import stock_selector as ss
  r = ss.recommend_stocks(1.0, -0.4, risk_scale=1.0)
  self.assertEqual(r['quadrant'], 'rising_growth_falling_inflation')
  self.assertIn('QQQ', r['recommended_etfs'])


 def test_micro_stock_fundamentals(self):
  import stock_selector as ss
  stocks = [
   {'ticker': 'AAPL', 'fcf_yield': 0.04, 'earnings_growth': 0.12, 'debt_to_equity': 1.5},
   {'ticker': 'BAD', 'fcf_yield': -0.02, 'earnings_growth': 0.20, 'debt_to_equity': 0.5},
   {'ticker': 'MSFT', 'fcf_yield': 0.05, 'earnings_growth': 0.15, 'debt_to_equity': 0.4},
  ]
  res = ss.score_stock_fundamentals(stocks)
  self.assertEqual([r['ticker'] for r in res], ['MSFT', 'AAPL'])


 def test_macro_micro_monte_carlo(self):
  import stock_selector as ss
  res = ss.macro_micro_monte_carlo(0.10, 0.20, growth_z=1.0, rate_shock=0.0, trials=300)
  self.assertTrue(res['expected_return'] > 0.10)
  self.assertTrue(res['kelly_size'] > 0.0)


 def test_sector_relative_and_coverage(self):
  import stock_selector as ss
  stocks = [
   {'ticker': 'A', 'sector': 'TECH', 'ev_ebitda': 15.0, 'interest_coverage': 8.0},
   {'ticker': 'B', 'sector': 'TECH', 'ev_ebitda': 25.0, 'interest_coverage': 6.0},
   {'ticker': 'C', 'sector': 'TECH', 'ev_ebitda': 10.0, 'interest_coverage': 1.5},
  ]
  res = ss.score_sector_relative(stocks)
  self.assertEqual([r['ticker'] for r in res], ['A', 'B'])
  self.assertTrue(res[0]['sector_rel_value'] > 0)

if __name__=='__main__':unittest.main()
