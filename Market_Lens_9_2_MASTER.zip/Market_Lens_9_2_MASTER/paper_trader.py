"""Paper-trading execution & live P&L tracker with spread/slippage modeling."""
import math, statistics
from alpha_engine import run_alpha_step

def realized_vols(price_series, window=20):
    """Compute annualized realized volatility from daily price lists."""
    vols = {}
    for asset, px in price_series.items():
        if len(px) < 3:
            continue
        tail = px[-(window + 1):]
        rets = [math.log(b / a) for a, b in zip(tail, tail[1:]) if a > 0 and b > 0]
        if len(rets) >= 2:
            vols[asset] = statistics.stdev(rets) * math.sqrt(252)
    return vols

def step_paper_portfolio(csv_path, price_series, prev_weights, nav=100.0, cost_bps=10.0, at=None):
    """Execute one rebalance step with fail-closed signals, realized vols, and transaction costs."""
    vols = realized_vols(price_series)
    res = run_alpha_step(csv_path, vols, at=at)
    new_w = res['weights']
    all_assets = set(prev_weights) | set(new_w)
    turnover = sum(abs(new_w.get(a, 0.0) - prev_weights.get(a, 0.0)) for a in all_assets)
    cost = nav * turnover * (cost_bps / 10000.0)
    return {'nav_after_cost': nav - cost, 'turnover': turnover, 'cost': cost, 'weights': new_w, 'regime': res['regime']}

def monte_carlo_confidence(active_returns, trials=1000, seed=42):
    """Bootstrap Monte Carlo test of active returns vs benchmark (returns mean, 95% CI, and win probability)."""
    import random
    if len(active_returns) < 6:
        return {'ok': False, 'reason': 'insufficient history'}
    rng = random.Random(seed)
    n = len(active_returns)
    means = sorted(statistics.mean(rng.choices(active_returns, k=n)) for _ in range(trials))
    lo = means[int(0.025 * trials)]
    hi = means[int(0.975 * trials)]
    prob_pos = sum(1 for m in means if m > 0) / trials
    return {'ok': True, 'mean': statistics.mean(active_returns), 'ci_95': [lo, hi], 'prob_beat_benchmark': prob_pos}

def adapt_risk_from_paper(active_returns, min_scale=0.5, max_scale=1.0):
    """Safely learn from paper-trading results using Sharpe-weighted consistency."""
    if len(active_returns) < 5:
        return 0.75
    recent = active_returns[-10:]
    mean_ret = statistics.mean(recent)
    sd_ret = statistics.stdev(recent) if len(recent) >= 2 else 0.0
    sharpe = (mean_ret / sd_ret) if sd_ret > 1e-9 else (1.0 if mean_ret > 0 else -1.0)
    win_rate = sum(1 for r in recent if r > 0) / len(recent)
    if mean_ret < 0 or win_rate < 0.45 or sharpe < 0:
        return min_scale
    if mean_ret > 0 and win_rate >= 0.55 and sharpe >= 0.30:
        return max_scale
    return 0.75
