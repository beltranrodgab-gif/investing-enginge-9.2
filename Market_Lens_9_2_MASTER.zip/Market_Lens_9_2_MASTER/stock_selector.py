"""Macro-to-Micro Stock & Sector Analyzer: EV/EBITDA, ROIC, Altman Z, Monte Carlo, and Kelly."""
import random, statistics
from signal_filter import classify_macro_quadrant
from alpha_engine import kelly_fraction

SECTOR_MAP = {
    'rising_growth_falling_inflation': ['SPY', 'QQQ', 'XLK', 'XLY'],
    'rising_growth_rising_inflation':  ['XLE', 'XLB', 'XLI', 'GLD'],
    'falling_growth_rising_inflation': ['XLP', 'XLU', 'XLV', 'GLD'],
    'falling_growth_falling_inflation':['TLT', 'IEF', 'XLV', 'XLP'],
    'unknown':                         ['SGOV', 'BIL'],
}

def recommend_stocks(growth_z, inflation_z, risk_scale=1.0):
    quad = classify_macro_quadrant(growth_z, inflation_z)
    return {'quadrant': quad, 'risk_scale': risk_scale, 'recommended_etfs': SECTOR_MAP.get(quad, SECTOR_MAP['unknown'])}

def score_stock_fundamentals(stocks, max_debt_eq=2.5, max_ev_ebitda=20.0, min_roic=0.10, min_altman_z=1.8):
    """Filter & rank stocks by FCF yield, earnings growth, EV/EBITDA, ROIC, Altman Z, and leverage."""
    passed = []
    for s in stocks:
        if s.get('debt_to_equity', 99) > max_debt_eq or s.get('fcf_yield', -1) <= 0:
            continue
        ev = s.get('ev_ebitda', 12.0)
        roic = s.get('roic', 0.15)
        az = s.get('altman_z', 3.0)
        if ev <= 0 or ev > max_ev_ebitda or roic < min_roic or az < min_altman_z:
            continue
        score = round(0.4 * s.get('fcf_yield', 0) + 0.3 * s.get('earnings_growth', 0) + 0.3 * roic - 0.01 * ev - 0.05 * s.get('debt_to_equity', 0), 4)
        passed.append({'ticker': s['ticker'], 'score': score, 'ev_ebitda': ev, 'roic': roic, 'altman_z': az})
    passed.sort(key=lambda x: -x['score'])
    return passed

def macro_micro_monte_carlo(base_return, base_vol, growth_z=0.0, rate_shock=0.0, trials=500, seed=42):
    """Simulate macro shock impact on a firm's return distribution and compute Fractional Kelly size."""
    rng = random.Random(seed)
    adj_mean = base_return + 0.03 * float(growth_z) - 0.04 * float(rate_shock)
    sims = [rng.gauss(adj_mean, base_vol) for _ in range(trials)]
    var = statistics.variance(sims) if len(sims) >= 2 else base_vol ** 2
    kelly = kelly_fraction(statistics.mean(sims), var, fraction=0.5, max_weight=0.40)
    prob_pos = sum(1 for r in sims if r > 0) / trials
    return {'expected_return': round(statistics.mean(sims), 4), 'prob_positive': round(prob_pos, 4), 'kelly_size': kelly}

def score_sector_relative(stocks, min_interest_cov=3.0):
    """Filter by interest coverage (>=3.0x) and rank stocks relative to their own sector's average EV/EBITDA."""
    valid = [s for s in stocks if s.get('interest_coverage', 5.0) >= min_interest_cov and s.get('ev_ebitda', 0) > 0]
    by_sec = {}
    for s in valid:
        by_sec.setdefault(s.get('sector', 'ALL'), []).append(s['ev_ebitda'])
    sec_avg = {sec: statistics.mean(vals) for sec, vals in by_sec.items()}
    out = []
    for s in valid:
        avg_ev = sec_avg[s.get('sector', 'ALL')]
        rel_val = round((avg_ev - s['ev_ebitda']) / avg_ev, 4) if avg_ev > 0 else 0.0
        out.append({'ticker': s['ticker'], 'sector': s.get('sector', 'ALL'), 'sector_rel_value': rel_val})
    out.sort(key=lambda x: -x['sector_rel_value'])
    return out


def risk_parity_allocation(assets: list[dict], safety_tilt: float = 1.5, max_weight: float = 0.45) -> dict:
    """Compute Standard Risk Parity (1/vol), Safer-Tilted (1/vol^1.5), and Return-Adjusted Sustainable Risk Parity."""
    if not assets:
        return {"standard": {}, "adjusted_safe": {}, "return_adjusted": {}, "safety_tilt": safety_tilt}
    vols, rets = {}, {}
    for a in assets:
        sym = str(a.get("symbol", "")).upper()
        vol = max(float(a.get("volatility", a.get("vol", 0.20))), 0.01)
        ret = max(float(a.get("expected_return", a.get("return", 0.08))), 0.0)
        if sym:
            vols[sym] = vol
            rets[sym] = ret
    if not vols:
        return {"standard": {}, "adjusted_safe": {}, "return_adjusted": {}, "safety_tilt": safety_tilt}

    std_raw = {k: 1.0 / v for k, v in vols.items()}
    std_sum = sum(std_raw.values())
    standard = {k: round(w / std_sum, 4) for k, w in std_raw.items()}

    adj_raw = {k: 1.0 / (v ** safety_tilt) for k, v in vols.items()}
    adj_sum = sum(adj_raw.values())
    adjusted = {k: min(w / adj_sum, max_weight) for k, w in adj_raw.items()}
    adj_norm = sum(adjusted.values()) or 1.0
    adjusted_safe = {k: round(w / adj_norm, 4) for k, w in adjusted.items()}

    ret_raw = {k: (1.0 + rets[k]) / (vols[k] ** 1.25) for k in vols}
    ret_sum = sum(ret_raw.values())
    ret_capped = {k: min(w / ret_sum, max_weight) for k, w in ret_raw.items()}
    ret_norm = sum(ret_capped.values()) or 1.0
    return_adjusted = {k: round(w / ret_norm, 4) for k, w in ret_capped.items()}

    return {
        "standard": standard,
        "adjusted_safe": adjusted_safe,
        "return_adjusted": return_adjusted,
        "safety_tilt": safety_tilt,
    }


def kalman_filter_series(series: list[float], process_var: float = 1e-4, meas_var: float = 1e-2) -> dict:
    """1D Kalman Filter for smoothing noisy macro (inflation, rates, GDP) and micro (earnings, margins) signals."""
    if not series:
        return {"filtered": [], "latest": None, "uncertainty": None}
    x = float(series[0])
    p_cov = 1.0
    filtered = []
    for z in series:
        p_pred = p_cov + process_var
        k_gain = p_pred / (p_pred + meas_var)
        x = x + k_gain * (float(z) - x)
        p_cov = (1.0 - k_gain) * p_pred
        filtered.append(round(x, 6))
    return {"filtered": filtered, "latest": filtered[-1], "uncertainty": round(p_cov, 6)}


def correlation_matrix(series_map: dict[str, list[float]]) -> dict[str, dict[str, float]]:
    """Compute Pearson correlation matrix across macro, micro, or asset return series."""
    keys = [k for k, v in series_map.items() if len(v) >= 2]
    mat: dict[str, dict[str, float]] = {k: {} for k in keys}
    for i, ki in enumerate(keys):
        xi = [float(v) for v in series_map[ki]]
        for j, kj in enumerate(keys):
            if j < i:
                mat[ki][kj] = mat[kj][ki]
                continue
            if i == j:
                mat[ki][kj] = 1.0
                continue
            xj = [float(v) for v in series_map[kj]]
            n = min(len(xi), len(xj))
            a, b = xi[-n:], xj[-n:]
            ma, mb = sum(a) / n, sum(b) / n
            num = sum((va - ma) * (vb - mb) for va, vb in zip(a, b))
            da = sum((va - ma) ** 2 for va in a) ** 0.5
            db = sum((vb - mb) ** 2 for vb in b) ** 0.5
            mat[ki][kj] = round(num / (da * db), 4) if da > 0 and db > 0 else 0.0
    return mat


def markov_regime_chain(regimes: list[str], steps: int = 1) -> dict:
    """Estimate Markov transition matrix across market valuation regimes and project next-step probabilities."""
    if len(regimes) < 2:
        cur = regimes[-1] if regimes else "NEUTRAL"
        return {"current_regime": cur, "transition_matrix": {}, "next_probabilities": {cur: 1.0}}
    states = sorted(set(regimes))
    counts = {s: {t: 0 for t in states} for s in states}
    for a, b in zip(regimes[:-1], regimes[1:]):
        counts[a][b] += 1
    matrix = {}
    for s in states:
        tot = sum(counts[s].values())
        matrix[s] = {t: round(counts[s][t] / tot, 4) if tot > 0 else round(1.0 / len(states), 4) for t in states}
    dist = {s: (1.0 if s == regimes[-1] else 0.0) for s in states}
    for _ in range(max(1, int(steps))):
        nxt = {t: 0.0 for t in states}
        for s, p_s in dist.items():
            for t, p_st in matrix[s].items():
                nxt[t] += p_s * p_st
        dist = nxt
    return {
        "current_regime": regimes[-1],
        "transition_matrix": matrix,
        "next_probabilities": {k: round(v, 4) for k, v in dist.items()},
    }


def black_swan_heat_diffusion(assets: list[dict], shock_temp: float = 2.5, diffusion: float = 0.35, seed: int = 42) -> dict:
    """Model Black Swan tail-risk shocks using random particle heat distribution in metals (Boltzmann spikes + thermal diffusion)."""
    import random, math
    rng = random.Random(seed)
    if not assets:
        return {"stressed_assets": {}, "tail_var_99": 0.0, "recommended_cash_buffer": 0.25}
    temps = {}
    for a in assets:
        sym = str(a.get("symbol", "")).upper()
        vol = max(float(a.get("volatility", a.get("vol", 0.20))), 0.01)
        if sym:
            # Random particle kinetic energy spike (exponential/Boltzmann tail)
            energy = -math.log(max(rng.random(), 1e-6)) * shock_temp * vol
            temps[sym] = energy
    avg_temp = sum(temps.values()) / max(len(temps), 1)
    # Thermal diffusion: heat spreads across correlated assets like a metal lattice
    diffused = {k: round((1.0 - diffusion) * v + diffusion * avg_temp, 4) for k, v in temps.items()}
    tail_var_99 = round(max(diffused.values()) * 1.65, 4) if diffused else 0.0
    cash_buffer = round(min(0.60, max(0.10, tail_var_99 * 0.5)), 4)
    return {
        "stressed_assets": diffused,
        "tail_var_99": tail_var_99,
        "recommended_cash_buffer": cash_buffer,
    }


def walk_forward_backtest(returns: list[float], risk_free: float = 0.02, fee_bps: float = 5.0) -> dict:
    """Walk-forward backtest computing cumulative return, annualized Sharpe, and max drawdown."""
    if not returns:
        return {"cumulative_return": 0.0, "sharpe": 0.0, "max_drawdown": 0.0}
    equity, peak, max_dd = 1.0, 1.0, 0.0
    for r in returns:
        equity *= (1.0 + float(r) - (fee_bps / 10000.0))
        peak = max(peak, equity)
        dd = (peak - equity) / peak if peak > 0 else 0.0
        max_dd = max(max_dd, dd)
    mean_r = sum(returns) / len(returns)
    var_r = sum((r - mean_r) ** 2 for r in returns) / max(len(returns) - 1, 1)
    std_r = var_r ** 0.5
    sharpe = ((mean_r * 252 - risk_free) / (std_r * (252 ** 0.5))) if std_r > 0 else 0.0
    return {
        "cumulative_return": round(equity - 1.0, 4),
        "sharpe": round(sharpe, 3),
        "max_drawdown": round(max_dd, 4),
    }


def format_jarvis_alert(regime: str, cash_buffer: float, tail_var: float) -> str:
    """Format a concise J.A.R.V.I.S. alert for Telegram/Email/Mobile."""
    return f"[OBSIDIAN ECONOMICS // J.A.R.V.I.S.] Regime={regime} | CashBuffer={cash_buffer*100:.1f}% | TailVaR99={tail_var:.2f}"


def drawdown_circuit_breaker(equity_curve: list[float], max_dd_limit: float = 0.08) -> dict:
    """Hard circuit breaker: if drawdown >= max_dd_limit (default 8%), force >= 50% defensive cash."""
    if not equity_curve:
        return {"triggered": False, "current_drawdown": 0.0, "forced_cash_floor": 0.10}
    peak = max(equity_curve)
    cur = equity_curve[-1]
    dd = (peak - cur) / peak if peak > 0 else 0.0
    triggered = dd >= max_dd_limit
    return {
        "triggered": triggered,
        "current_drawdown": round(dd, 4),
        "forced_cash_floor": 0.50 if triggered else 0.10,
    }


def stage_broker_order(symbol: str, side: str, qty: float, approved: bool = False) -> dict:
    """Human-in-the-loop order staging: never executes live without explicit approved=True."""
    return {
        "symbol": str(symbol).upper(),
        "side": str(side).upper(),
        "qty": round(float(qty), 4),
        "status": "READY_TO_EXECUTE" if approved else "STAGED_AWAITING_APPROVAL",
        "approved": bool(approved),
    }


def fx_hedge_ratio(asset_vol: float, fx_vol: float, corr: float = 0.0) -> float:
    """Compute minimum-variance FX hedge ratio for multi-currency (e.g. EUR/USD) portfolios."""
    if fx_vol <= 0:
        return 0.0
    h = -(corr * asset_vol) / fx_vol
    return round(max(0.0, min(1.0, 0.5 + h)), 4)


def backup_state_dir(src_dir: str, backup_dir: str) -> str:
    """Create a timestamped zip backup of MarketLens62 state and J.A.R.V.I.S. reports."""
    import datetime, zipfile
    from pathlib import Path
    src, dst = Path(src_dir), Path(backup_dir)
    dst.mkdir(parents=True, exist_ok=True)
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = dst / f"MarketLens_Backup_{ts}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        if src.exists():
            for p in src.rglob("*"):
                if p.is_file():
                    z.write(p, p.relative_to(src))
    return str(out)


def diversification_score(corr_matrix: dict[str, dict[str, float]]) -> dict:
    """Ray Dalio check: measure average off-diagonal correlation to ensure truly uncorrelated return streams."""
    keys = list(corr_matrix.keys())
    if len(keys) < 2:
        return {"avg_correlation": 0.0, "diversified": True}
    vals = [corr_matrix[a][b] for i, a in enumerate(keys) for j, b in enumerate(keys) if i < j and b in corr_matrix[a]]
    avg_c = sum(vals) / len(vals) if vals else 0.0
    return {"avg_correlation": round(avg_c, 4), "diversified": avg_c < 0.45}


def statistical_edge_zscore(returns: list[float]) -> dict:
    """Jim Simons check: test whether mean return is statistically significant (t-stat >= 2.0) vs. noise."""
    n = len(returns)
    if n < 2:
        return {"t_stat": 0.0, "statistically_significant": False}
    mean_r = sum(returns) / n
    var_r = sum((r - mean_r) ** 2 for r in returns) / (n - 1)
    se = (var_r / n) ** 0.5
    t_stat = mean_r / se if se > 0 else 0.0
    return {"t_stat": round(t_stat, 3), "statistically_significant": t_stat >= 2.0}


def dalio_quadrant_weights(growth_trend: float, inflation_trend: float) -> dict:
    """Ray Dalio All-Weather 4-quadrant macro allocation."""
    if growth_trend >= 0 and inflation_trend < 0:
        q = "RISING_GROWTH_FALLING_INFLATION"
        w = {"equities": 0.45, "bonds": 0.35, "commodities": 0.10, "cash": 0.10}
    elif growth_trend >= 0 and inflation_trend >= 0:
        q = "RISING_GROWTH_RISING_INFLATION"
        w = {"equities": 0.35, "bonds": 0.15, "commodities": 0.35, "cash": 0.15}
    elif growth_trend < 0 and inflation_trend >= 0:
        q = "FALLING_GROWTH_RISING_INFLATION"
        w = {"equities": 0.15, "bonds": 0.25, "commodities": 0.35, "cash": 0.25}
    else:
        q = "FALLING_GROWTH_FALLING_INFLATION"
        w = {"equities": 0.20, "bonds": 0.50, "commodities": 0.10, "cash": 0.20}
    return {"quadrant": q, "weights": w}


def half_kelly_position_size(expected_return: float, volatility: float, max_cap: float = 0.35) -> float:
    """Jim Simons Half-Kelly sizing: f* = 0.5 * (mu / sigma^2), capped at max_cap."""
    v = max(float(volatility), 0.01)
    kelly = 0.5 * (float(expected_return) / (v ** 2))
    return round(max(0.0, min(max_cap, kelly)), 4)


def bear_market_alpha(regime: str, rsi: float, price_to_intrinsic: float, cash_buffer: float) -> dict:
    """Buffett (deep-value panic deployment) + Kotegawa/BNF (oversold capitulation bounce) + Bear-market hedge."""
    actions = []
    if str(regime).upper() == "BEAR":
        actions.append("HEDGE_BEAR_REGIME (TLT/GLD/Inverse)")
    if price_to_intrinsic <= 0.75 and cash_buffer >= 0.15:
        actions.append("BUFFETT_PANIC_DEPLOY (25%+ discount to intrinsic value)")
    if rsi <= 25.0:
        actions.append("KOTEGAWA_OVERSOLD_BOUNCE (RSI <= 25 mean-reversion)")
    if not actions:
        actions.append("HOLD_DEFENSIVE_CASH")
    return {"regime": regime, "rsi": rsi, "price_to_intrinsic": price_to_intrinsic, "actions": actions}


def vol_target_scale(current_vol: float, target_vol: float = 0.10, max_scale: float = 1.25, min_scale: float = 0.50) -> float:
    """Scale exposure up in calm markets and down in panics to keep portfolio risk constant."""
    v = max(float(current_vol), 0.01)
    scale = float(target_vol) / v
    return round(max(min_scale, min(max_scale, scale)), 4)


def trailing_stop_lock(entry_price: float, peak_price: float, current_price: float, trail_pct: float = 0.06, min_gain: float = 0.15) -> dict:
    """Lock in profits once a position gains >= min_gain (15%) by trailing a stop at trail_pct (6%) below peak."""
    gain = (peak_price - entry_price) / entry_price if entry_price > 0 else 0.0
    stop_price = peak_price * (1.0 - trail_pct)
    triggered = gain >= min_gain and current_price <= stop_price
    return {"active": gain >= min_gain, "stop_price": round(stop_price, 4), "exit_triggered": triggered}


def rebalance_with_drift_threshold(current_weights: dict[str, float], target_weights: dict[str, float], min_drift: float = 0.03) -> dict:
    """Only trade assets whose weight drifted by >= min_drift (3%) to eliminate over-trading and fee drag."""
    trades = {}
    for sym, tgt in target_weights.items():
        cur = float(current_weights.get(sym, 0.0))
        diff = float(tgt) - cur
        if abs(diff) >= min_drift:
            trades[sym] = round(diff, 4)
    return {"rebalance_needed": bool(trades), "trades": trades}


def apply_sector_cap(weights: dict[str, float], sector_map: dict[str, str], max_sector_weight: float = 0.30) -> dict[str, float]:
    """Cap total allocation per sector at max_sector_weight (30%) and re-normalize."""
    sector_totals: dict[str, float] = {}
    for sym, w in weights.items():
        sec = sector_map.get(sym, "OTHER")
        sector_totals[sec] = sector_totals.get(sec, 0.0) + float(w)
    capped = {}
    for sym, w in weights.items():
        sec = sector_map.get(sym, "OTHER")
        tot = sector_totals.get(sec, 0.0)
        scale = min(1.0, max_sector_weight / tot) if tot > 0 else 1.0
        capped[sym] = float(w) * scale
    norm = sum(capped.values()) or 1.0
    return {k: round(v / norm, 4) for k, v in capped.items()}


def liquidity_and_earnings_gate(avg_daily_dollar_vol: float, days_to_earnings: int | None = None, min_dollar_vol: float = 10_000_000.0, blackout_days: int = 3) -> dict:
    """Block illiquid stocks (< $10M/day) and binary pre-earnings gambles (<= 3 days to earnings)."""
    liquid = float(avg_daily_dollar_vol) >= min_dollar_vol
    earnings_safe = True if days_to_earnings is None else int(days_to_earnings) > blackout_days
    return {"allowed": liquid and earnings_safe, "liquid": liquid, "earnings_safe": earnings_safe}


def out_of_sample_split_test(returns: list[float], train_ratio: float = 0.70) -> dict:
    """Anti-overfitting check: compare in-sample (70%) vs. unseen out-of-sample (30%) Sharpe."""
    if len(returns) < 10:
        return {"in_sample_sharpe": 0.0, "out_of_sample_sharpe": 0.0, "overfit_warning": False}
    split = max(2, int(len(returns) * train_ratio))
    in_s = walk_forward_backtest(returns[:split])["sharpe"]
    out_s = walk_forward_backtest(returns[split:])["sharpe"]
    overfit = (in_s > 0.5) and (out_s < 0.5 * in_s)
    return {"in_sample_sharpe": in_s, "out_of_sample_sharpe": out_s, "overfit_warning": overfit}


def tax_aware_exit_check(holding_days: int, unrealized_pnl_pct: float) -> dict:
    """Favor long-term capital gains (>= 365 days) on winners; allow tax-loss harvesting on <= -5% losers."""
    is_ltcg = int(holding_days) >= 365
    harvest_loss = float(unrealized_pnl_pct) <= -0.05
    hold_for_tax = (float(unrealized_pnl_pct) > 0.0) and (not is_ltcg)
    return {"long_term_gains": is_ltcg, "harvest_loss": harvest_loss, "hold_for_tax": hold_for_tax}


def fast_shock_detector(latest_return: float, daily_vol: float) -> dict:
    """Instant 3-sigma shock detector so the engine reacts immediately without waiting for Kalman/Markov lag."""
    v = max(float(daily_vol), 0.005)
    z = abs(float(latest_return)) / v
    return {"z_shock": round(z, 2), "shock_triggered": z >= 3.0}


def detect_1h_order_block_and_candle(candles_1h: list[dict]) -> dict:
    """Detect 1H institutional Order Block (bullish/bearish) and candlestick confirmation (Engulfing / Pinbar)."""
    if len(candles_1h) < 3:
        return {"order_block": None, "candle_confirmation": None, "signal": "NONE"}
    c_prev, c_curr = candles_1h[-2], candles_1h[-1]
    o1, h1, l1, cl1 = float(c_prev["open"]), float(c_prev["high"]), float(c_prev["low"]), float(c_prev["close"])
    o2, h2, l2, cl2 = float(c_curr["open"]), float(c_curr["high"]), float(c_curr["low"]), float(c_curr["close"])

    ob = None
    if cl1 < o1 and cl2 > h1:
        ob = {"type": "BULLISH_OB", "zone_low": l1, "zone_high": h1}
    elif cl1 > o1 and cl2 < l1:
        ob = {"type": "BEARISH_OB", "zone_low": l1, "zone_high": h1}

    body2 = abs(cl2 - o2)
    rng2 = max(h2 - l2, 1e-6)
    lower_wick = min(o2, cl2) - l2
    upper_wick = h2 - max(o2, cl2)

    conf = None
    if cl2 > o2 and cl1 < o1 and cl2 >= o1 and o2 <= cl1:
        conf = "BULLISH_ENGULFING"
    elif cl2 < o2 and cl1 > o1 and cl2 <= o1 and o2 >= cl1:
        conf = "BEARISH_ENGULFING"
    elif lower_wick >= 2.0 * body2 and (lower_wick / rng2) >= 0.55:
        conf = "BULLISH_PINBAR"
    elif upper_wick >= 2.0 * body2 and (upper_wick / rng2) >= 0.55:
        conf = "BEARISH_PINBAR"

    signal = "LONG" if (ob and ob["type"] == "BULLISH_OB" and conf in ("BULLISH_ENGULFING", "BULLISH_PINBAR")) else (
        "SHORT" if (ob and ob["type"] == "BEARISH_OB" and conf in ("BEARISH_ENGULFING", "BEARISH_PINBAR")) else "WATCH" if ob else "NONE"
    )
    return {"order_block": ob, "candle_confirmation": conf, "signal": signal}
