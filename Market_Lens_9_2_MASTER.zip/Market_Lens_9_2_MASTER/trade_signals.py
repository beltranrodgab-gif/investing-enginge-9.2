"""Convert processor target weights into explicit BUY / SELL / HOLD order instructions."""

def generate_orders(current_weights, target_weights, portfolio_value=10000.0, min_trade_pct=0.02):
    """Compare current vs target weights and emit explicit BUY / SELL / HOLD orders."""
    orders = []
    for asset in sorted(set(current_weights) | set(target_weights)):
        cur = current_weights.get(asset, 0.0)
        tgt = target_weights.get(asset, 0.0)
        diff = round(tgt - cur, 6)
        if abs(diff) < min_trade_pct:
            orders.append({'asset': asset, 'action': 'HOLD', 'delta_pct': 0.0, 'amount_usd': 0.0})
        elif diff > 0:
            orders.append({'asset': asset, 'action': 'BUY', 'delta_pct': diff, 'amount_usd': round(diff * portfolio_value, 2)})
        else:
            orders.append({'asset': asset, 'action': 'SELL', 'delta_pct': abs(diff), 'amount_usd': round(abs(diff) * portfolio_value, 2)})
    return orders
